#ifndef __aluguel_hpp__ // ifndef inclui o comentário apenas uma vez 
#define __aluguel_hpp__

#include <string>
#include <iostream>
#include "pessoa.hpp"
#include "carro.hpp"


class Aluguel{
private: //atributos
    pessoa* cliente; //ponteiro do tipo pessoa com nome cliente 
    carro* veiculo;
    std::string dataInicio;
    std::string dataFim;
    double valor; // valor do aluguel final;
    bool alugado;

public: // metodos / construtores
    // Construtor default
    Aluguel();
    //construtor parametrizado
    Aluguel(pessoa* ucliente, carro* ucarro, std::string udataInicio, std::string udataFim, double uvalor);

    // Getters
    int getId() const;
    pessoa* getCliente() const;
    carro* getCarro() const;
    std::string getDataInicio() const;
    std::string getDataFim() const;
    double getValor() const;
    bool estaAtivo() const;
    // Setters
    void setId(int uid);
    void setCliente(pessoa* ucliente);
    void setCarro(carro* ucarro);
    void setDataInicio(std::string udataInicio);
    void setDataFim(std::string udataFim);
    void setValor(double uvalor);
    void setAtivo(bool uativo);

    // Cálculo do valor final da diária
    double calculaValorAluguel() const;
};

#endif // __aluguel_hpp__