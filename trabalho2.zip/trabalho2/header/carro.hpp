#ifndef __carro_hpp__
#define __carro_hpp__

#include <string>
#include <iostream>

class carro{
    friend class Aluguel;
    private:
    double valor; // valor base
    std::string placa;
    std::string modelo;
    std::string observaçao;
    int ano;
    float quilometragem;
    bool situaçao; //se esta pronto para uso(nao disponivel = True || disponivel = false)
    public:
        //CONSTRUTORES
        carro(); // construtor default
        carro(double uvalor ,std::string uplaca, std::string umodelo, std::string uobservaçao, int uano, float uquilometragem, bool usituaçao); // construtor parametrizado
        carro(const carro& outro); // construtor de copia

        //getters
        float getvalor() const;
        std::string getplaca() const;
        std::string getmodelo() const;
        std::string getobservaçao() const;
        int getano() const;
        float getquilometragem() const;
        bool getsituaçao() const;

        //setters
        double setvalor(double uvalorcarro);
        std::string setplaca(std::string uplaca);
        std::string setmodelo(std::string umodelo);
        std::string setobservaçao(std::string uobservaçao);
        int setano(int uano);
        float setquilometragem(float uquilometragem);
        bool setsituaçao(bool usituaçao);
};

#endif // __carro_hpp__