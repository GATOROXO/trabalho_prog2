#ifndef __locadora_hpp__
#define __locadora_hpp__

#include <string>
#include <iostream>
#include <vector>
#include <format>
#include "pessoa.hpp"
#include "carro.hpp"   
#include "aluguel.hpp"
#include "pessoafisica.hpp"
#include "pessoajuridica.hpp"

class Locadora {
    private:
        std::vector<pessoa*> clientes;
        std::vector<carro*> carros;
        std::vector<Aluguel> alugueis;

    public:
        //construtor default
        Locadora();

        //destrutor
        ~Locadora();

        //getters
        std::vector<pessoa*> getClientes() const;
        std::vector<carro*> getCarros() const;
        std::vector<Aluguel> getAlugueis() const;

        // Métodos para agregação - recebem objetos já criados
        void adicionarCliente(pessoa* cliente);
        void adicionarCarro(carro* novoCarro);
        void adicionarAluguel(const Aluguel& novoAluguel);

        // Métodos de operação do sistema
        void registrarAluguel(std::string placaCarro, int id_cliente, std::string dataInicio, std::string dataFim, double valor);
        void registrarDevolucao(std::string placaCarro, float kmFinal);
        
        // Métodos auxiliares para manipulação de alugueis
        int obterIndiceAluguelPorPlaca(std::string placaCarro);
        Aluguel* obterAluguelPorPlaca(std::string placaCarro);
        bool removerAluguelPorPlaca(std::string placaCarro);

        // Métodos para gerar relatórios
        void gerarRelatorioCarrosAlugados(std::string dataInicio, std::string dataFim) const;
        void gerarRelatorioFaturamento(std::string dataInicio, std::string dataFim); 
        void gerarRelatorioClientesComDividas();
        void consultarDadosCliente(int id_cliente);
        void consultarCarroporPlaca(std::string placa);
        void listarClientes();
        void listarCarrosdisponiveis();

        
        // Novos métodos para funcionalidades adicionais
        int contardiasEntreAnos(std::string dataInicio, std::string dataFim);
        bool pagarDividaCliente(int id_cliente);
        void listarAlugueisDoCliente(int id_cliente);
        pessoa* buscarClientePorId(int id_cliente);
        carro* buscarCarroPorPlaca(std::string placa);
        //void listarCarrosDisponiveis();
            


        
        //metodos de pagamentos 
        int buscarIDclientePorAluguel(int ID_unico);
        int escolher_pagamento(int id_cliente);
}; 

#endif //__locadora_hpp__

