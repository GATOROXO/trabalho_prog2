#ifndef __pessoa_hpp__
#define __pessoa_hpp__

#include <string>
#include <iostream>

//aqui neste arquivo irei guarda apenas os prototipos das funçoes, seguindo a boa pratica de programação, e irei separar um arquivo 
//para a declaração das funções

//A classe pessoa se trata de uma classe base, onde as classes que iram herdar "pessoa", sao as classes derivadas como : pessoa fisica,
//juridica e a locadora de veiculos.

class pessoa{
    friend class Aluguel;
    protected:
        std::string nome;
        int ID_unico;
        std::string endereço;
        std::string telefone;
        float valor_divida;

    public:
        //CONSTRUTORES
        pessoa(); // construtor padrão
        pessoa(std::string unome, std::string uendereço, std::string utelefone, float valor_divida); // construtor parametrizado
        pessoa(const pessoa& outro); // construtor por copia

        // DESTRUTOR VIRTUAL - NECESSÁRIO PARA POLIMORFISMO E DYNAMIC_CAST
        virtual ~pessoa();

        //função inline(estatico) para criar o id_unico da pessoa. (ainda devo conferir se nao vai conflitar com nada)
        inline static int prox_ID = 1;

        //getters padrões:
        std::string getnome() const;
        int getID_unico() const;
        std::string getendereço() const;
        std::string gettelefone() const;
        float getvalor_divida() const;

        //setters
        std::string setnome(std::string unome);
        std::string setendereço(std::string uendereço);
        std::string settelefone(std::string utelefone);
        float setvalor_divida(float uvalor);
};

#endif //__pessoa_hpp__;