#ifndef __pessoafisica_hpp__
#define __pessoafisica_hpp__

#include <string>
#include <iostream>
#include "pessoa.hpp"

class pessoafisica : public pessoa{
    private:
        int nivel_de_relacionamento;
        std::string cpf;
    public:
        // construtores
        pessoafisica(); // construtor default
        pessoafisica(std::string unome, std::string uendereço, std::string utelefone, float uvalor_divida, int univel_relacionamento, std::string ucpf); // construtor parametrizado
        pessoafisica(const pessoafisica& outrof); // construtor por cópia

        // setters
        std::string setcpf(std::string ucpf);
        int setnivel_de_relacionamento(int univel);

        // getters
        std::string getcpf() const;
        int getnivel_de_relacionamento() const;
};

#endif // __pessoafisica_hpp__