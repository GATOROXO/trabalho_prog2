#ifndef __pessoajuridica_hpp__
#define __pessoajuridica_hpp__

#include <string>
#include <iostream>
#include "pessoa.hpp"

class pessoajuridica : public pessoa{
    private:
        std::string cnpj;
    public:
        // construtores
        pessoajuridica(); // Construtor default
        pessoajuridica(std::string unome, std::string uendereço, std::string utelefone, float uvalor_divida, std::string ucnpj); // construtor parametrizado
        pessoajuridica(const pessoajuridica& outroj); // construtor por copia

        // getter 
        std::string getcnpj() const;

        // setter
        std::string setcnpj(std::string ucnpj);

};

#endif // __pessoajuridica_hpp__


//atributos = private// são atributos da classe, uma ferrari também é um carro, na linguagem de programação a ferrari é uma classe derivado de carro
// carro é classe base, uma ferrare é uma classe derivada de carro 