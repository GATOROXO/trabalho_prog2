#include "locadora.hpp"
#include "pessoafisica.hpp"
#include "pessoajuridica.hpp"
#include "carro.hpp"
#include <iostream>
#include <string>
#include <limits>
//ta entrando em recursao ou chamada infita

void limparBuffer() {
    std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n'); 
}
int main() {
    Locadora loc;
    system("chcp 65001"); //deixar bem formatado. aceita pontuação e caracteres diferentes.s
    int opcao{-1};
    while (opcao != 0) {
        std::cout << "\n============= MENU LOCADORA =============\n";
        std::cout << "1 - Cadastrar cliente\n";
        std::cout << "2 - Cadastrar carro\n";
        std::cout << "3 - Registrar aluguel\n";
        std::cout << "4 - Registrar devolução\n";
        std::cout << "5 - Consultar cliente\n";
        std::cout << "6 - Listar clientes\n";
        std::cout << "7 - Listar aluguéis de cliente\n";
        std::cout << "8 - Relatório faturamento\n";
        std::cout << "9 - Relatório clientes com dívidas\n";
        std::cout << "10 - Consultar carro\n";
        std::cout << "11 - Listar carros disponiveis\n";
        std::cout << "0 - Sair\nOpção: ";
        std::cin >> opcao;
        limparBuffer();
        switch (opcao) {
            case 1: { // cadastrar cliente
                int tipo;
                std::cout << "Tipo (1=Física, 2=Jurídica): ";
                std::cin >> tipo;
                limparBuffer();
                std::cout << "ID_unico gerado: " << pessoa::getID_unico << std::endl;
                std::string nome, endereco, telefone; 
                std::cout << "Nome/Razão Social: "; 
                std::getline(std::cin, nome);
                std::cout << "Endereço: "; 
                std::getline(std::cin, endereco);
                std::cout << "Telefone: "; 
                std::getline(std::cin, telefone);
                float divida; std::cout << "Dívida inicial (R$): "; 
                std::cin >> divida; 
                limparBuffer();
                
                
                if (tipo == 1) {
                    int nivel; std::cout << "Nível relacionamento (1-5): "; 
                    std::cin >> nivel;
                    limparBuffer();
                    std::string cpf; 
                    std::cout << "CPF: "; 
                    std::getline(std::cin, cpf);
                    loc.adicionarCliente(new pessoafisica(nome, endereco, telefone, divida, nivel, cpf));
                    std::cout << "Cliente físico cadastrado.\n";
                } 
                else if (tipo == 2) {
                    std::string cnpj; 
                    std::cout << "CNPJ: "; 
                    std::getline(std::cin, cnpj);
                    loc.adicionarCliente(new pessoajuridica(nome, endereco, telefone, divida, cnpj));
                    std::cout << "Cliente jurídico cadastrado.\n";
                } 
                else {
                    std::cout << "Tipo inválido.\n";
                }
                break;
            }
            case 2: { // cadastrar carro
                std::string placa, modelo; 
                int ano; 
                double valor; 
                float km;
                std::cout << "Placa: "; 
                std::getline(std::cin, placa);
                std::cout << "Modelo: "; 
                std::getline(std::cin, modelo);
                std::cout << "Ano: "; 
                std::cin >> ano;
                std::cout << "Valor (R$): "; 
                std::cin >> valor;
                std::cout << "Quilometragem: "; 
                std::cin >> km;
                limparBuffer();
                loc.adicionarCarro(new carro(valor, placa, modelo, "", ano, km, false));
                std::cout << "Carro cadastrado.\n";
                break; 
            }
            case 3: { // registrar aluguel
                std::string placa, di, df; 
                int idCliente; 
                std::cout << "Placa: "; 
                std::getline(std::cin, placa);
                std::cout << "ID Cliente: "; 
                std::cin >> idCliente; 
                limparBuffer();
                std::cout << "Data início (dd/mm/aaaa): "; 
                std::getline(std::cin, di);
                std::cout << "Data fim (dd/mm/aaaa): ";
                std::getline(std::cin, df);
                loc.registrarAluguel(placa, idCliente, di, df, 0.0);
                break; 
            }
            case 4: { // registrar devolução
                std::string placa; 
                float kmFinal;
                std::cout << "Placa: "; 
                std::getline(std::cin, placa);
                std::cout << "KM final: ";
                std::cin >> kmFinal;
                limparBuffer();
                loc.registrarDevolucao(placa, kmFinal);
                break; 
            }
            case 5: { // consultar cliente
                int id;
                std::cout << "ID cliente: "; 
                std::cin >> id; 
                loc.consultarDadosCliente(id); 
                limparBuffer();
                break;
            }
            case 6: { // listar clientes
                loc.listarClientes(); 
                break; 
            }
            case 7: { // listar alugueis cliente
                int id; 
                std::cout << "ID cliente: "; 
                std::cin >> id; 
                limparBuffer();
                loc.listarAlugueisDoCliente(id); 
                break; 
            }
            case 8: { // relatorio faturamento
                std::string ini, fim; 
                std::cout << "Data início (dd/mm/aaaa): "; 
                std::getline(std::cin, ini); 
                std::cout << "Data fim (dd/mm/aaaa): "; 
                std::getline(std::cin, fim);
                loc.gerarRelatorioFaturamento(ini, fim); 
                break; 
            }
            case 9: { // relatorio dividas
                loc.gerarRelatorioClientesComDividas(); 
                break; 
            }
            case 10: { // consultar carro
                std::string placa;
                std::cout << "Placa do carro: ";
                std::getline(std::cin, placa);
                loc.consultarCarroporPlaca(placa);
                break;
            }
            case 11: {
                loc.listarCarrosdisponiveis();
                break;
            }

            case 0:
                std::cout << "Encerrando...\n";
                break;
            default:
                std::cout << "Opção inválida.\n";
        }
    }
    return 0;
}
