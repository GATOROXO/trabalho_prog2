#include "aluguel.hpp"
#include "pessoafisica.hpp"

// Implementação do construtor default
Aluguel::Aluguel() : cliente{nullptr}, veiculo{nullptr}, dataInicio{"00/00/0000"}, dataFim{"00/00/0000"}, valor{0.0}, alugado{false} {
}

// Implementação do construtor parametrizado
Aluguel::Aluguel(pessoa* ucliente, carro* ucarro, std::string udataInicio, std::string udataFim, double uvalor) :
    cliente{ucliente}, veiculo{ucarro}, dataInicio{udataInicio}, dataFim{udataFim}, valor{uvalor}, alugado{true} {
    // Note que uid não é mais usado, pois usaremos o ID da pessoa
    if(uvalor > 0){
        valor = uvalor;
    }
    else{
        valor = 0.0;
    }
}


// Implementação dos getters
int Aluguel::getId() const {
    if (cliente != nullptr) {
        return cliente->ID_unico;  //Acesso direto ao membro privado
    }
    return -1;  // valor padrão pra quando tiver ID.
}

pessoa* Aluguel::getCliente() const {
    return cliente;
}

carro* Aluguel::getCarro() const {
    return veiculo;
}

std::string Aluguel::getDataInicio() const {
    return dataInicio;
}

std::string Aluguel::getDataFim() const {
    return dataFim;
}

double Aluguel::getValor() const {
    return valor;
}

bool Aluguel::estaAtivo() const {
    return alugado;
}

// Implementação dos setters
void Aluguel::setId(int uid) {
    // Como agora usamos o ID da pessoa, este método pode apenas avisar que não é usado
    // Ou você pode remover este método do header se não quiser mais usá-lo
    // Note: Este método não faz nada pois o ID vem da pessoa automaticamente
}

void Aluguel::setCliente(pessoa* ucliente) {
    cliente = ucliente;
}

void Aluguel::setCarro(carro* ucarro) {
    veiculo = ucarro;
}

void Aluguel::setDataInicio(std::string udataInicio) {
    dataInicio = udataInicio;
}

void Aluguel::setDataFim(std::string udataFim) {
    dataFim = udataFim;
}

void Aluguel::setValor(double uvalor) {
    valor = uvalor;
}

void Aluguel::setAtivo(bool uativo) { // define se o carro ja esta alugado ou nao
    alugado = uativo;
}

double Aluguel::calculaValorAluguel() const {
    if (veiculo == nullptr || cliente == nullptr) {
        return 0.0;
    }

    double valorBase = veiculo->valor;
    if (valorBase < 0.0) {
        valorBase = 0.0;
    }

    // Ajuste conforme idade do carro
    int anoCarro = veiculo->ano;
    int anoAtual = 2025; //colocado manualmente

    double fatorCarro = 1.0;
    int idade = anoAtual - anoCarro;
    if (idade <= 0) {
        fatorCarro += 0.50; // carro do ano ou futuro
    } else if (idade <= 2) {
        fatorCarro += 0.20; // até 2 anos de uso
    }

    double descontoCliente = 0.0;
    if (auto pf = dynamic_cast<pessoafisica*>(cliente)) {
        switch (pf->getnivel_de_relacionamento()) {
            case 5: descontoCliente = 0.20; 
            break;
            case 4: descontoCliente = 0.15; 
            break;
            case 3: descontoCliente = 0.10; 
            break;
            case 2: descontoCliente = 0.05; 
            break;
            default: descontoCliente = 0.0; 
            break;
        }
    }

    double valorFinal = valorBase * fatorCarro;
    valorFinal *= (1.0 - descontoCliente);
    if (valorFinal < 0.0) {
        valorFinal = 0.0;
    }

    return valorFinal;
}

