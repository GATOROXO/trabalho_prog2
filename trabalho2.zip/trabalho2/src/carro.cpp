#include "carro.hpp"

// Implementação do construtor default
carro::carro() :
    valor{0.00}, placa{"LLLNLNN"}, modelo{"{modelo}"}, observaçao{"{observaçao}"}, ano{2000}, quilometragem{0.0f}, situaçao{false} {
    //nada
}

// Implementação do construtor parametrizado
carro::carro(double uvalor, std::string uplaca, std::string umodelo, std::string uobservaçao, int uano, float uquilometragem, bool usituaçao) :
    valor{uvalor}, placa{uplaca}, modelo{umodelo}, observaçao{uobservaçao}, ano{uano}, quilometragem{uquilometragem}, situaçao{usituaçao} {

    if(uvalor > 0){
        valor = uvalor;
    }
    else{
        valor = 0.0;
    }
    
    if(uplaca.length() != 7) {
        placa = "LLLNLNN";
    } else {
        placa = uplaca;
    }

    if(uquilometragem < 0) {
        quilometragem = 0;
    } else {
        quilometragem = uquilometragem;
    }

    if(uano > 2025 || uano < 0) {
        ano = 1500;
    } else {
        ano = uano;
    }
}

// Implementação do construtor de cópia
carro::carro(const carro& outro) :
placa{outro.placa}, modelo{outro.modelo}, observaçao{outro.observaçao}, ano{outro.ano}, quilometragem{outro.quilometragem}, situaçao{outro.situaçao} {
    //nada necessario.
}

float carro::getvalor()const{
    return valor;
}

// Implementação dos getters
std::string carro::getplaca() const {
    return placa;
}

std::string carro::getmodelo() const {
    return modelo;
}

std::string carro::getobservaçao() const {
    return observaçao;
}

int carro::getano() const {
    return ano;
}

float carro::getquilometragem() const {
    return quilometragem;
}

bool carro::getsituaçao() const {
    return situaçao;
}

// Implementação dos setters
std::string carro::setplaca(std::string uplaca) {
    if(uplaca.length() != 7) {
        placa = "LLLNLNN";
    } else {
        placa = uplaca;
    }
    return placa;
}

std::string carro::setmodelo(std::string umodelo) {
    return modelo = umodelo;
}

std::string carro::setobservaçao(std::string uobservaçao) {
    return observaçao = uobservaçao;
}

double carro::setvalor(double uvalorcarro){
    if(valor >0){
        valor = uvalorcarro;
    }
    else{
        valor = 0.0;
    }
    return valor;
}

int carro::setano(int uano) {
    if(uano > 2025 || uano < 0) {
        ano = 1500;
    } else {
        ano = uano;
    }
    return ano;
}

float carro::setquilometragem(float uquilometragem) {
    if(uquilometragem < 0) {
        quilometragem = 0;
    } else {
        quilometragem = uquilometragem;
    }
    return quilometragem;
}

bool carro::setsituaçao(bool usituaçao) {
    return situaçao = usituaçao;
}