#include "locadora.hpp"

//construtor default
Locadora::Locadora() {
    // Os vetores se inicializam automaticamente vazios - não precisa de nullptr
}

// Implementação do destrutor
Locadora::~Locadora() {

}

// getters
std::vector<pessoa*> Locadora::getClientes() const {
    return clientes;
}

std::vector<carro*> Locadora::getCarros() const {
    return carros;
}

std::vector<Aluguel> Locadora::getAlugueis() const {
    return alugueis;
}

// Implementação dos métodos para agregação
void Locadora::adicionarCliente(pessoa* cliente) {
    if (cliente != nullptr) {
        clientes.push_back(cliente);
        std::cout << "Cliente " << cliente->getnome() << " adicionado com sucesso!" << std::endl;
    } else {
        std::cout << "Erro: Cliente inválido!" << std::endl;
    }
}

void Locadora::adicionarCarro(carro* novoCarro) {
    carros.push_back(novoCarro);
    std::cout << "Carro " << novoCarro->getmodelo() << " - " << novoCarro->getplaca() << " adicionado com sucesso!" << std::endl;
}

void Locadora::adicionarAluguel(const Aluguel& novoAluguel) {
    alugueis.push_back(novoAluguel);
    std::cout << "Aluguel registrado com sucesso!" << std::endl;
}

// Implementação dos métodos de operação do sistema
void Locadora::registrarAluguel(std::string placaCarro, int id_cliente, std::string dataInicio, std::string dataFim, double valor) {
    //busca o carro pela placa
    carro* carroEncontrado = nullptr;
    for (int i=0; i < carros.size(); i++) {
        if (carros.at(i)->getplaca() == placaCarro && carros.at(i)->getsituaçao() == false) { // carro disponível
            carroEncontrado = carros.at(i);
            break;
        };
    }
    
    if (carroEncontrado == nullptr) {
        std::cout << "Erro: Carro com placa " << placaCarro << " não encontrado ou não disponível!" << std::endl;
        return;
    }
    
    // busca cliente pelo id_unico
    pessoa* clienteEncontrado = nullptr;
    for (int i=0; i < clientes.size(); i++) {
        if (clientes[i]->getID_unico() == id_cliente) {
            clienteEncontrado = clientes[i];
            break;
        }
    }
    
    if (clienteEncontrado == nullptr) {
        std::cout << "Erro: Cliente com ID " << id_cliente << " não encontrado!" << std::endl;
        return;
    }
    
    // marca carro como não disponível
    carroEncontrado->setsituaçao(true);

    if (valor <= 0.0) {
        valor = carroEncontrado->getvalor();
    }

    // Cria aluguel provisório, calcula a diária ajustada e ajusta o valor
    Aluguel novoAluguel(clienteEncontrado, carroEncontrado, dataInicio, dataFim, valor);
    double valorCalculado = novoAluguel.calculaValorAluguel();
    novoAluguel.setValor(valorCalculado);
    novoAluguel.getCliente()->setvalor_divida(clienteEncontrado->getvalor_divida()+valorCalculado);
    alugueis.push_back(novoAluguel); // gambiarra funcional...

    std::cout << "Aluguel registrado com sucesso!" << std::endl;
    std::cout << "Cliente: " << clienteEncontrado->getnome() << " (ID: " << clienteEncontrado->getID_unico() << ")" << std::endl;
    std::cout << "Carro: " << carroEncontrado->getmodelo() << " - " << carroEncontrado->getplaca() << std::endl;
    std::cout << "Período: " << dataInicio << " até " << dataFim << std::endl;
    std::cout << "Valor calculado da diária: R$ " << valorCalculado << std::endl;
}

void Locadora::registrarDevolucao(std::string placaCarro, float kmFinal) {
    // Primeiro verifica se existe um aluguel ativo para este carro
    int indiceAluguel = obterIndiceAluguelPorPlaca(placaCarro);
    
    if (indiceAluguel == -1) {
        std::cout << "Erro: Não existe aluguel ativo para o carro com placa " << placaCarro << std::endl;
        return;
    }

    int id_cliente = alugueis.at(indiceAluguel).getCliente()->getID_unico();
    int cliente_encontrado = buscarIDclientePorAluguel(id_cliente);
    if(cliente_encontrado == -1){
        std::cout << "Cliente com id " << id_cliente << " não existe!\n";
        return;
    }
    if(escolher_pagamento(id_cliente) == 3){
        std::cout << "Voltando ao main";
        return;
    }

    // Obtém referência ao aluguel encontrado 
    Aluguel& aluguelAtivo = alugueis[indiceAluguel];
    
    // Obtém o carro associado ao aluguel
    carro* carroEncontrado = aluguelAtivo.getCarro();
    
    if (carroEncontrado == nullptr) {
        std::cout << "Erro: Carro associado ao aluguel é inválido!" << std::endl;
        return;
    }
    

    // Atualiza a quilometragem do carro
    carroEncontrado->setquilometragem(kmFinal);
    
    // Marca o carro como disponível novamente
    carroEncontrado->setsituaçao(true);
    
    // Mensagens de sucesso da devolução
    std::cout << "\n=== DEVOLUÇÃO REALIZADA COM SUCESSO ===\n" 
              << "Cliente: " << aluguelAtivo.getCliente()->getnome() 
              << " (ID: " << aluguelAtivo.getCliente()->getID_unico() << ")\n" 
              << "Carro: " << carroEncontrado->getmodelo() 
              << " - Placa: " << carroEncontrado->getplaca() 
              << "\nQuilometragem final: " << kmFinal << " km\n" 
              << "O carro foi devolvido com sucesso e está disponível para novos alugueis.\n"
              << "=========================================" << std::endl;
    
}
// função auxiliar para a registrar devolução ou pagar dividas
int Locadora::escolher_pagamento(int id_cliente){
    int metodo;
    std::cout << "Digite o metodo de pagamento desejado \n"
                 "1 - para pagar parcial\n"
                 "2 - pagar completo\n"
                 "3 - para voltar" << std::endl;
    std::cin >> metodo;
    pessoa * cliente_encontrado = buscarClientePorId(id_cliente);

    switch (metodo)
    {
    case 1:
        {
            std::cout << "digite o valor à pagar: ";
            float valor_pago;
            std::cin >> valor_pago;
            float divida = cliente_encontrado->getvalor_divida();
            std::cout << "Cliente : " << cliente_encontrado->getnome()
                      << "\ndivida atual: " << divida - valor_pago << "R$" << std::endl;
            clientes.at(id_cliente)->setvalor_divida(divida - valor_pago);
            return 1;
        }

    case 2:
        std::cout << "Cliente : " << cliente_encontrado->getnome()
                  << "\ndivida atual: 0.0 R$" << std::endl;
        cliente_encontrado->setvalor_divida(0);
        return 2;

    case 3:
        //volta a funçao chamadora
        return 3;

    default:
        std::cout << "Digite um valor valido para o metodo: ";
        return escolher_pagamento(id_cliente);
    }
}



// Implementação dos métodos para gerar relatórios
void Locadora::gerarRelatorioCarrosAlugados(std::string dataInicio, std::string dataFim) const {
    //gerar relatŕoio
    std::cout << "Relatório de carros alugados: " << dataInicio << "até" << dataFim << "---" <<std::endl; 
    for(auto& registro : alugueis) {
        // verifica se o periodo do aluguel se sobrepõe ao periodo do relatório 
        if (registro.getDataInicio() <= dataFim && registro.getDataFim() >= dataInicio && registro.estaAtivo()==true) {
            std::cout << "\n-------------------------------------------------------------" << std::endl;
            std::cout << "Alugado por " << registro.getCliente()->getnome() << "com ID_unico: " << registro.getCliente()->getID_unico() <<
                         "\nCarro alugado: " << registro.getCarro()->getmodelo() << " com a placa: " << registro.getCarro()->getplaca() << std::endl;
        }
    }
    return;
}

void Locadora::gerarRelatorioFaturamento(std::string dataInicio, std::string dataFim) {

    std::cout <<   "=========RELATÓRIO DE FATURAMENTO==========" << std::endl;

    std::cout <<   "Período: " << dataInicio << " até " << dataFim << std::endl;

    double totalFaturado{0.0};
    int qtdAlugueis{0};

    
    for (const auto& aluguel : alugueis) {
        // Considera apenas aluguéis dentro do período informado
        if (aluguel.getDataInicio() >= dataInicio && aluguel.getDataFim() <= dataFim) {
            std::cout << "\nAluguel ID: " << aluguel.getId() << std::endl;
            std::cout << "Cliente: " << aluguel.getCliente()->getnome() << std::endl;
            std::cout << "Carro: " << aluguel.getCarro()->getmodelo() << " - " << aluguel.getCarro()->getplaca() << std::endl;
            std::cout << "Período: " << aluguel.getDataInicio() << " até " << aluguel.getDataFim() << std::endl;
            std::cout << "Valor: R$ " << aluguel.getValor() << std::endl;
            totalFaturado += aluguel.getValor();
            qtdAlugueis++;
        }
    }

    std::cout << "\n----------------------------------------------" << std::endl;
    std::cout << "Total de aluguéis no período: " << qtdAlugueis << std::endl;
    float valor_faturado_bruto = (contardiasEntreAnos(dataInicio, dataFim) * totalFaturado);
    std::cout << "Faturamento total Bruto(sem descontos) : R$ " << totalFaturado << std::endl;
    std::cout << "----------------------------------------------" << std::endl;
}

void Locadora::gerarRelatorioClientesComDividas() {
    // implementação vazia - pode ser customizada conforme necessário
    std::cout << "\n-------- Relatório de Clientes com Dívidas---------- " << std::endl;

    bool encontrouDividas = false; 
    for (int i =0; i < clientes.size (); i++){
        pessoa* cliente = clientes.at(i);
        float divida;
        divida = cliente->getvalor_divida();

        if (divida > 0){
            encontrouDividas = true; 
            std::cout << "\nCliente: " << cliente->getnome() << std::endl;
            std::cout << "ID: " << cliente->getID_unico() << std::endl;
            std::cout << "Telefone: " << cliente->gettelefone() << std::endl;
            std::cout << std::format("Valor da dívida: R$  {:.2f}", cliente->getvalor_divida()) << std::endl;
            
            //Identificar tipo do cliente

            pessoafisica* pf = dynamic_cast<pessoafisica*>(cliente);
            pessoajuridica* pj = dynamic_cast<pessoajuridica*>(cliente);
            
            if (pf) {
                std::cout << "Tipo: Pessoa Física - CPF: " <<  pf->getcpf() << std::endl;
            }else if (pj){
                std::cout << "Tipo: Pessoa Jurídica - CNPJ: " << pj->getcnpj() << std::endl;
            }
        }
    }
    
    if (!encontrouDividas) {
        std::cout << "\nNenhum cliente com dívidas pendentes encontrado." << std::endl;
    }
    
    std::cout << "\n--------------------------------------------------- " << std::endl;
    
}   

void Locadora::consultarDadosCliente(int id_cliente) {// lógica para verificar se o cliente está aqui ou se ele existe 
    
    pessoa * cliente_encontrado = nullptr;
    
    for(int i =0; i<clientes.size(); i++){
        if(clientes.at(i)->getID_unico() == id_cliente){
            cliente_encontrado = clientes.at(i); 
        }
    }
    
    if(!cliente_encontrado){
        std::cout << "Cliente com id " << id_cliente << " não existe ou não esta cadastrado!" << std::endl;
        return;
    }
    
    std::cout << "Nome : " << cliente_encontrado->getnome() <<
    "\nID_unico: " << cliente_encontrado->getID_unico() << 
    "\nendereço: " << cliente_encontrado->getendereço() <<
    "\ntelefone: " << cliente_encontrado->gettelefone() <<
    "\nvalor da divida: " << cliente_encontrado->getvalor_divida() << std::endl;
    
    pessoafisica * pf = dynamic_cast<pessoafisica*>(cliente_encontrado);
    pessoajuridica * pj = dynamic_cast<pessoajuridica*>(cliente_encontrado);
    
    if(pf){
        std::cout << "Tipo de cliente: Pessoa Física" << std::endl;
        std::cout << "CPF: " << pf->getcpf() << std::endl;
        std::cout << "Nível de relacionamento: " << pf->getnivel_de_relacionamento() << std::endl;
        return;
    }
    else if(pj){
        std::cout << "Tipo de cliente: Pessoa Jurídica" << std::endl;
        std::cout << "CNPJ: " << pj->getcnpj() << std::endl;
        return;
    }
}
void Locadora::consultarCarroporPlaca(std::string placa){
    carro * carro_encontrado = nullptr;
    for(int i= 0; i<carros.size(); i++){
        if(carros.at(i)->getplaca() == placa){
            carro_encontrado = carros.at(i);
            break;
        }
    }
    if(!carro_encontrado){
        std::cout << "Nenhum carro com a placa " << placa << "foi encontrado na locadora." << std::endl;
        return;
    }
    if(carro_encontrado->getsituaçao() == true){
        std::cout << "=========O carro \"JÁ\" esta alugado!========";
        Aluguel * alugado  = obterAluguelPorPlaca(placa);
        if(alugado->estaAtivo() == true){
            std::cout << "\nAlugado por: " << alugado->getCliente()->getnome() << std::endl;
        }
    }
    else{
        std::cout << "=========O carro \"NÃO\" esta alugado!========";
    }

    std::cout << "Dados do carro" <<
    "\nModelo: " << carro_encontrado->getmodelo() << 
    "\nplaca: " << carro_encontrado->getplaca() <<
    "\nano: " << carro_encontrado->getano() <<
    "\nquilometragem: " << carro_encontrado->getquilometragem() <<
    "\nvalor: " << carro_encontrado->getvalor() << 
    "\nobservação: " << carro_encontrado->getobservaçao() << std::endl;
}

bool Locadora::pagarDividaCliente(int id_cliente){
    pessoa * cliente_encontrado = nullptr;
    for(int i =0; i<clientes.size(); i++){
        if(clientes.at(i)->getID_unico() == id_cliente){
            cliente_encontrado = clientes.at(i); 
        }
    }
    
    if(!cliente_encontrado){
        std::cout << "Cliente com id " << id_cliente << " não existe ou não esta cadastrado!" << std::endl;
        return false;
    }
    if(escolher_pagamento(id_cliente)==3){
        std::cout << "Voltando ao inicio!" << std::endl;
        return false;
    }
    std::cout << "Perfil do cliente atualizado com sucesso!\n\n";
    consultarDadosCliente(id_cliente);
    return true;
}

void Locadora::listarAlugueisDoCliente(int id_cliente){
    pessoa * cliente_encontrado = buscarClientePorId(id_cliente);
    if(!cliente_encontrado){ //devo implementar ainda a funçao de buscar cliente por id
        std::cout << "O id_unico " << id_cliente << " não existe para nenhum cliente!" << std::endl;
        return;
    }
    std::cout << "Cliente : " << cliente_encontrado->getnome() <<
                 "\nID_unico: " << cliente_encontrado->getID_unico() << std::endl;
    int contador{0};
    for(int i=0; i <alugueis.size(); i++){
        if((alugueis.at(i).getCliente()->getID_unico() == id_cliente) && (alugueis.at(i).estaAtivo()==true)){
            std::cout << "Modelo : " << alugueis.at(i).getCarro()->getmodelo() <<
            "\nplaca: " << alugueis.at(i).getCarro()->getplaca() << std::endl;
            std::cout << "\n--------------------------------------------------- " << std::endl;
            contador++;
        }
    }
    if(contador == 0){
        std::cout << "não possui veiculos alugados" << std::endl;
    }
    
    std::cout << "fim!\nVoltando ao inicio!" << std::endl;
    return;
}

// Métodos auxiliares para manipulação de alugueis

// Método que retorna o índice do aluguel ativo baseado na placa do carro
// Retorna -1 se não encontrar nenhum aluguel ativo para o carro
int Locadora::obterIndiceAluguelPorPlaca(std::string placaCarro){
    for (int i = 0; i < alugueis.size(); i++) {
        // Verifica se o aluguel está ativo e se a placa do carro batem
        if (alugueis[i].estaAtivo() && 
            alugueis[i].getCarro()->getplaca() == placaCarro) {
            return i;
        }
    }
    return -1; // Não encontrou
}

// Método que retorna um ponteiro para o aluguel ativo baseado na placa do carro
// Retorna nullptr se não encontrar nenhum aluguel ativo para o carro
Aluguel* Locadora::obterAluguelPorPlaca(std::string placaCarro) {
    int indice = obterIndiceAluguelPorPlaca(placaCarro);
    if (indice != -1) {
        return &alugueis[indice];
    }
    return nullptr;
}

// Método que remove completamente um aluguel do vetor baseado na placa do carro
// Retorna true se encontrou e removeu, false caso contrário
// ATENÇÃO: Use com cuidado pois remove permanentemente o registro do aluguel
bool Locadora::removerAluguelPorPlaca(std::string placaCarro) {
    int indice = obterIndiceAluguelPorPlaca(placaCarro);
    if (indice != -1) {
        // Remove o elemento do vetor
        alugueis.erase(alugueis.begin() + indice);    // aponta um elemento dentro do vector 
        std::cout << "Aluguel do carro " << placaCarro << " removido do sistema." << std::endl;
        return true;
    }
    std::cout << "Nenhum aluguel ativo encontrado para o carro " << placaCarro << std::endl;
    return false;
}

int Locadora::buscarIDclientePorAluguel(int ID_unico){
    for (int i = 0; i < alugueis.size(); i++) {
        // Verifica se o aluguel está ativo e se a placa do carro coincide
        if (alugueis[i].estaAtivo() && 
            alugueis[i].getCliente()->getID_unico() == ID_unico) {
            return i;
        }
    }
    return -1; // nao encontrou
}

pessoa* Locadora::buscarClientePorId(int idCliente) {
    for (int i = 0; i < clientes.size(); i++) {
        if (clientes.at(i)->getID_unico() == idCliente) {
            return clientes.at(i);
        }
    }
    return nullptr; // nao encontrou
}

carro* Locadora::buscarCarroPorPlaca(std::string placa){
    for(int i = 0; i < carros.size(); i++){
        if(carros.at(i)->getplaca() == placa){
            return carros.at(i);
        }
    }
    return nullptr; // nao encontrou
}

 void Locadora::listarClientes(){
    std::cout << "=======TODOS OS CLIENTES=======" << std::endl;
    if (clientes.size() < 0) {
        std::cout << "\nNenhum cliente cadastrado." << std::endl;
        return ;
    }
    for (int i=0; i < clientes.size(); i++) {
        pessoa * cliente_encontrado = nullptr;
        cliente_encontrado = clientes.at(i); 
    
    if(!cliente_encontrado){
        std::cout << "Cliente com id " << i << " não existe ou não esta cadastrado!" << std::endl;
        return;
    }
    
        std::cout << "Nome : " << cliente_encontrado->getnome() <<
                     " -- ID_unico: " << cliente_encontrado->getID_unico() << std::endl;
}
    std::cout << "\nTotal de clientes: " << clientes.size() << std::endl;
    return;
}
void Locadora::listarCarrosdisponiveis(){
    std::cout << "=======Carros disponiveis========" << std::endl;
    if(carros.empty()){
        std::cout << "não ha carros cadastrados." << std::endl;
        return;
    }
    bool encontrouDisponivel;
    for(int i = 0; i<carros.size(); i++){
        if (!carros.at(i)->getsituaçao()) { // se NÃO está alugado == disponível
            encontrouDisponivel = true;
            std::cout << "Modelo: " << carros[i]->getmodelo()
                      << "\nPlaca: " << carros[i]->getplaca()
                      << "\nAno: " << carros[i]->getano()
                      << "\nValor: R$ " << carros[i]->getvalor()
                      << "\nKM: " << carros[i]->getquilometragem()
                      << std::endl;
        }
        if (!encontrouDisponivel) {
        std::cout << "Nenhum carro disponível no momento." << std::endl;
        }
    }
}

int Locadora::contardiasEntreAnos(std::string dataInicio, std::string dataFim){
    std::string dias_inicio = dataInicio.substr(0,2);
    std::string mes_inicio = dataInicio.substr(3,2);
    std::string ano_inicio = dataInicio.substr(6,4);
    std::string dias_fim = dataFim.substr(0,2);
    std::string mes_fim  = dataFim.substr(3,2);
    std::string ano_fim = dataFim.substr(6,4);

    int anoi = std::stoi(ano_inicio), anof = std::stoi(ano_fim), quantDias{0}, diai = std::stoi(dias_inicio), diaf = std::stoi(dias_fim);
    int mesi = std::stoi(mes_inicio), mesf = std::stoi(mes_fim), anopro{0}, mespro{0};
    
    anopro = anoi+1;

    if(anoi != anof){ //ano inical e final diferentes
            //avaliar os anos intermerdiarios 
            // que possuem a quantidade completa de dias
        while(anopro < anof){
            if(anopro%400 == 0) quantDias = quantDias + 366;
            else if(anopro%100 != 0 && anopro%4 == 0) quantDias = quantDias + 366;
            else quantDias = quantDias + 365;
            anopro++;
        }
        //para ano inicial diferente de ano final.
        //Calculo no ano inicial
        mespro = mesi;
        while(mespro <= 12){
            if(mespro == mesi){//verificação do mês inicial, precisa descontar a quantidade de dias corridos
                if(mesi <= 7 && mesi%2 == 1) quantDias+=31 - (diai - 1);
                //verficande de janeiro a julho
                else if (mesi <= 7 && mesi%2 == 0 && mesi != 2) quantDias+=30 - (diai - 1);
                else if(mesi == 2){
                if(anoi%400 == 0) quantDias = quantDias + 29 - (diai - 1);//C espressão normal
                else if(anoi%100 != 0 && anoi%4 == 0) quantDias += 29 - (diai - 1);//C reduzido
                else quantDias += 28 - (diai - 1);
                } //verificando de agosto a dezembro
                else if(mesi > 7 && mesi%2== 0) quantDias+=31 - (diai - 1);
                else if(mesi > 7 && mesi%2== 1) quantDias+=30 - (diai - 1);
            } else{ //verficação de mês diferente do mês inical
                //verficande de janeiro a julho
                if(mespro <= 7 && mespro%2 == 1) quantDias+=31;// C reduzido 
                else if (mespro <= 7 && mespro%2 == 0 && mespro != 2) quantDias+=30;
                else if(mespro == 2){
                    if(anoi%400 == 0) quantDias = quantDias + 29;// Espressão normal
                    else if(anoi%100 != 0 && anoi%4 == 0) quantDias += 29;//C reduzido
                    else quantDias += 28;
                }//verificando de agosto a dezembro
                else if(mespro > 7 && mespro%2== 0) quantDias+=31;
                else if(mespro > 7 && mespro%2== 1) quantDias+=30;
            }

            mespro++;           
        }
    //Calculo ano final
        mespro = mesf;
        while (mespro >= 1)
        {
            if(mespro == mesf){//verificação do mês final, só conta a quantidade de dias corridos
                 quantDias+= diaf;
                 
            } else{ //verficação de mês diferente do mês final 
                if(mespro <= 7 && mespro%2 == 1) quantDias+=31;//janeiro a julho
                else if (mespro <= 7 && mespro%2 == 0 && mespro != 2) quantDias+=30;
                else if(mespro == 2){
                    if(anof%400 == 0) quantDias += 29;
                    else if(anof%100 != 0 && anof%4 == 0) quantDias += 29;
                    else quantDias += 28;
                } //agosto a dezembro
                else if(mespro > 7 && mespro%2== 0) quantDias+=31;
                else if(mespro > 7 && mespro%2== 1) quantDias+=30;
            }   
        mespro--;   
        }
    } else {// para ano inicial e ano final iguais
            mespro = mesi;
        while(mespro < mesf){
            if(mespro == mesi){//verificação do mês inicial, precisa descontar a quantidade de dias corridos
                if(mesi <= 7 && mesi%2 == 1) quantDias+=31 - (diai - 1);
                //verficande de janeiro a julho
                else if (mesi <= 7 && mesi%2 == 0 && mesi != 2) quantDias+=30 - (diai - 1);
                else if(mesi == 2){
                if(anoi%400 == 0) quantDias = quantDias + 29 - (diai - 1);//C espressão normal
                else if(anoi%100 != 0 && anoi%4 == 0) quantDias += 29 - (diai - 1);//C reduzido
                else quantDias += 28 - (diai - 1);
                } //verificando de agosto a dezembro
                else if(mesi > 7 && mesi%2== 0) quantDias+=31 - (diai - 1);
                else if(mesi > 7 && mesi%2== 1) quantDias+=30 - (diai - 1);
            } else{ //verficação de mês diferente do mês inical
                //verficande de janeiro a julho
                if(mespro <= 7 && mespro%2 == 1) quantDias+=31;// C reduzido 
                else if (mespro <= 7 && mespro%2 == 0 && mespro != 2) quantDias+=30;
                else if(mespro == 2){
                    if(anoi%400 == 0) quantDias = quantDias + 29;// Espressão normal
                    else if(anoi%100 != 0 && anoi%4 == 0) quantDias += 29;//C reduzido
                    else quantDias += 28;
                }//verificando de agosto a dezembro
                else if(mespro > 7 && mespro%2== 0) quantDias+=31;
                else if(mespro > 7 && mespro%2== 1) quantDias+=30;
            }
            
            mespro++;           
        }
        quantDias+= diaf; // recebendo dias do mes final
    }
    return quantDias;
};
