#include "pessoa.hpp"

// Implementação do construtor padrão
pessoa::pessoa() : nome{"|SEM NOME|"}, ID_unico{prox_ID}, endereço{"|SEM ENDEREÇO|"}, telefone{"|(00)00000-0000|"}, valor_divida{0.0} {
    prox_ID++;
}

// Implementação do construtor parametrizado
pessoa::pessoa(std::string unome, std::string uendereço, std::string utelefone, float uvalor_divida): 
    nome{unome}, ID_unico{prox_ID}, endereço{uendereço + '.'}, telefone{utelefone}, valor_divida{uvalor_divida} {
    
    if(utelefone.length() < 11 || utelefone.length() > 11) {
        telefone = "(00)00000-0000";
    } else {
        telefone = "(" + utelefone.substr(0, 2) + ") " + utelefone.substr(2, 5) + "-" + utelefone.substr(7, 4);
        //formato (00) 12345-6789
    }
    
    prox_ID++;
}

// Implementação do construtor por cópia
pessoa::pessoa(const pessoa& outro) :
    nome{outro.nome}, ID_unico{outro.ID_unico}, endereço{outro.endereço}, telefone{outro.telefone} {
    //nada pois é por copia
}

// Implementação do destrutor virtual
pessoa::~pessoa() {
    // Destrutor da classe base - pode estar vazio
    // O importante é que seja virtual para permitir polimorfismo correto
}


// Implementação dos getters
std::string pessoa::getnome() const {
    return nome;
}

int pessoa::getID_unico() const {
    return ID_unico;
}

std::string pessoa::getendereço() const {
    return endereço;
}

std::string pessoa::gettelefone() const {
    return telefone;
}
float pessoa::getvalor_divida() const {
    return valor_divida;
}

// Implementação dos setters
std::string pessoa::setnome(std::string unome) {
    nome = unome;
    return nome;
}

std::string pessoa::setendereço(std::string uendereço) {
    return endereço = uendereço + '.'; // o ponto serve para indicar fim do endereço
}

std::string pessoa::settelefone(std::string utelefone) {
    if(utelefone.length() < 11 || utelefone.length() > 11) {
        telefone = "(00)00000-0000";
    } else {
        telefone = "(" + utelefone.substr(0, 2) + ") " + utelefone.substr(2, 5) + "-" + utelefone.substr(7, 4);
        //formato (11) 99999-9999
    }
    return telefone;
}

float pessoa::setvalor_divida(float uvalor){
    return valor_divida = uvalor;
}