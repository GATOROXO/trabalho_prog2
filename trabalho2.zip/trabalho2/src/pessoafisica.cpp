#include "pessoafisica.hpp"

// Implementação do construtor default
pessoafisica::pessoafisica() :
    pessoa(), cpf{"000.000.000-00"}, nivel_de_relacionamento{1} {
    // nada
}

// Implementação do construtor parametrizado
pessoafisica::pessoafisica(std::string unome, std::string uendereço, std::string utelefone, float uvalor_divida, int univel_relacionamento, std::string ucpf) :
    pessoa(unome, uendereço, utelefone, uvalor_divida), nivel_de_relacionamento{univel_relacionamento}, cpf{ucpf} {
    
    if(univel_relacionamento < 1 || univel_relacionamento > 5) {
        nivel_de_relacionamento = 1; // nivel de cliente novo;
    } else {
        nivel_de_relacionamento = univel_relacionamento;
    }

    if(ucpf.length() < 11 || ucpf.length() > 11) {
        cpf = "000.000.000-00";
    } else {
        cpf = ucpf.substr(0,3) + "." + ucpf.substr(3,3) + "." + ucpf.substr(6,3) + "-" + ucpf.substr(9,2);
        //formato 123.456.789-01
    }
}

// Implementação do construtor por cópia
pessoafisica::pessoafisica(const pessoafisica& outrof) :
    pessoa(outrof), nivel_de_relacionamento{outrof.nivel_de_relacionamento}, cpf{outrof.cpf} {
    //nada pois se trata de uma copia que deu certo.
}

// Implementação dos setters
std::string pessoafisica::setcpf(std::string ucpf) {
    if(ucpf.length() < 11 || ucpf.length() > 11) {
        cpf = "000.000.000-00";
    } else {
        cpf = ucpf.substr(0,3) + "." + ucpf.substr(3,3) + "." + ucpf.substr(6,3) + "-" + ucpf.substr(9,2);
        //formato 123.456.789-01
    }
    return cpf;
}   

// Implementação dos getters
std::string pessoafisica::getcpf() const {
    return cpf;
}

int pessoafisica::getnivel_de_relacionamento() const {
    return nivel_de_relacionamento;
}

// Implementação do setter de nível
int pessoafisica::setnivel_de_relacionamento(int univel) {
    if(univel < 1 || univel > 5) {
        nivel_de_relacionamento = 1; // nível de cliente novo
    } else {
        nivel_de_relacionamento = univel;
    }
    return nivel_de_relacionamento;
}