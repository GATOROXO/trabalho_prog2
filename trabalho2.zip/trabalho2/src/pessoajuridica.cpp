#include "pessoajuridica.hpp"

// Implementação do construtor default
pessoajuridica::pessoajuridica() :
    pessoa(), cnpj{"12.345.678/0001-23"} {
    //nada
}

// Implementação do construtor parametrizado
pessoajuridica::pessoajuridica(std::string unome, std::string uendereço, std::string utelefone, float uvalor_divida, std::string ucnpj):
    pessoa(unome, uendereço, utelefone, uvalor_divida), cnpj{ucnpj} {
    
    if(ucnpj.length() < 14 || ucnpj.length() > 14) {
        cnpj = "12.345.678/0001-23";
    } else {
        cnpj = ucnpj.substr(0,2) + "." + ucnpj.substr(2,3) + "." + ucnpj.substr(5,3) + "/" + ucnpj.substr(8,4) + "-" + ucnpj.substr(12,2);
        //formato 12.345.678/0001-23
    }
}

// Implementação do construtor por cópia
pessoajuridica::pessoajuridica(const pessoajuridica& outroj) :
    pessoa(outroj), cnpj{outroj.cnpj} {
    //nada aqui pois é um construtor por copia
}

// Implementação do getter
std::string pessoajuridica::getcnpj() const {
    return cnpj;
}

// Implementação do setter
std::string pessoajuridica::setcnpj(std::string ucnpj) {
    if (ucnpj.length() < 14 || ucnpj.length() > 14) {
        cnpj = "12.345.678/0001-23";
    } else {
        cnpj = ucnpj.substr(0,2) + "." + ucnpj.substr(2,3) + "." + ucnpj.substr(5,3) + "/" + ucnpj.substr(8,4) + "-" + ucnpj.substr(12,2);
    }
    return cnpj;
}